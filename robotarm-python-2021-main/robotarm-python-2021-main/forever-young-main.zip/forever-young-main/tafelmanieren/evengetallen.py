for i in range(20,52,2):
    print(i)