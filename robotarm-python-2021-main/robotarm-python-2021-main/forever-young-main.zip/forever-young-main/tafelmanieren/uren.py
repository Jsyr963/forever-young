for i in range(0,25,1):
    if i < 13:
        print(i, "AM")
    else:
        print(i, "PM")
