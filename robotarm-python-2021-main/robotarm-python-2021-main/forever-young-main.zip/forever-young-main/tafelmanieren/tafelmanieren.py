tafel = int(input("Welke Tafel wil je leren ?"))

for i in range(1,11):
    print(f"{i} x {tafel} = ", i * tafel)